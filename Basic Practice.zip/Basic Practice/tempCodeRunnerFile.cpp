lse
//    {
//     cout<<s;
//    }